# 彩銘羽 CacheCleaner
完璧な掃除用具だ！

#### V1.3.0 (2024.02.11)
 - Module version created

#### V1.3.1 (2024.03.30)
 - Fix multiUser
 - Multi-language support(zh-CN)

#### V1.3.2 (2024.09.21)
 - riscv64 is supported
 - Optimized the code
 - Updated dependencies